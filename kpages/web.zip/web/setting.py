DEBUG = True
DB_NAME = 'kpages'
DB_HOST = 'localhost'
PORT = 8888
ACTION_DIR = ('testweb')
