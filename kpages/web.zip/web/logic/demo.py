# -*- coding:utf-8 -*-

from kpages import srvcmd

@srvcmd('demofun')
def demofun(data):
    print data
